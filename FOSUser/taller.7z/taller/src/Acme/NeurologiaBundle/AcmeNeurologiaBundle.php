<?php

namespace Acme\NeurologiaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeNeurologiaBundle extends Bundle
{
}
