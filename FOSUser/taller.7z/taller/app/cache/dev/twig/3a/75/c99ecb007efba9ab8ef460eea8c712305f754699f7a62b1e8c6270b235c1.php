<?php

/* AcmeNeurologiaBundle:Default:index2.html.twig */
class __TwigTemplate_3a75c99ecb007efba9ab8ef460eea8c712305f754699f7a62b1e8c6270b235c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hell";
    }

    public function getTemplateName()
    {
        return "AcmeNeurologiaBundle:Default:index2.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
