<?php

// FOSUserBundle:Group:show_content.html.twig
return array (
);
