<?php

namespace Salita\UsuarioBundle\Repository;

use Doctrine\ORM\EntityRepository;

class RolRepository extends EntityRepository
{
    public function findOneByCodigo($codigo)
    {
        return $this->getEntityManager()
            ->createQuery('SELECT r FROM SalitaUsuarioBundle:Rol r where r.codigo = ' .$codigo)
            ->getResult();
    }

    public function rolesAdministradorYMedico()
    {
        $codigoAdmin = "'".'ROLE_ADMINISTRADOR'."'";
        $codigoMedico = "'".'ROLE_MEDICO'."'";

        return $this->getEntityManager()
            ->createQuery('SELECT r FROM SalitaUsuarioBundle:Rol r where r.codigo = '.$codigoAdmin.' or r.codigo = '.$codigoMedico)
            ->getResult();
    }
}
