<?php

namespace Salita\UsuarioBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\MisRoles;

use Salita\UsuarioBundle\Clases\RolTemporal;
use Salita\UsuarioBundle\Form\Type\RolType;

class UsuarioRolController extends Controller
{
    public function elegirAction(Request $request)
    {
       $usuario = $this->container->get('security.context')->getToken()->getUser();
       
       if(($usuario->hasRole('ROLE_ADMINISTRADOR')) and ($usuario->hasRole('ROLE_MEDICO')))
       {
           $em = $this->getDoctrine()->getEntityManager();
           $roles = $em->getRepository('SalitaUsuarioBundle:Rol')->rolesAdministradorYMedico();
           $rolTemp = new RolTemporal();
           $form = $this->createForm(new RolType($roles), $rolTemp);

           if ($request->getMethod() == 'POST')
           {
               $form->bindRequest($request);
               if ($form->isValid())
               {
                   $_SESSION['idUsuario'] = $usuario->getId();

                   $rolElegido = $em->getRepository('SalitaUsuarioBundle:Rol')->findOneByCodigo($rolTemp->getNombre());
                   $rolElegido = $rolElegido[0];
                   $_SESSION['idRolSeleccionado'] = $rolElegido->getId();

                   $rolSeleccionado = $rolElegido->getCodigo();

                   if ($rolSeleccionado == 'ROLE_MEDICO')
                   {
                       $_SESSION['idEspecialidad'] = $usuario->getEspecialidad()->getId();
                   }           
               }       
           }
           else
           {
               return $this->render('SalitaUsuarioBundle:EleccionRolForm:eleccionRol.html.twig', array('form' => $form->createView(),));    
           }
          
       }
       else
       {
           $em = $this->getDoctrine()->getEntityManager();
           $_SESSION['idUsuario'] = $usuario->getId();
           $rolesUsuario = $usuario->getRoles();

           $idRolUsuario = $em->getRepository('SalitaUsuarioBundle:Rol')->findOneByCodigo("'".$rolesUsuario[0]."'");

           $_SESSION['idRolSeleccionado'] = $idRolUsuario[0]->getId();

           if ($usuario->hasRole('ROLE_MEDICO'))
           {
               $_SESSION['idEspecialidad'] = $usuario->getEspecialidad()->getId();
           }

           $rolSeleccionado = $rolesUsuario[0];
       }

       if ($rolSeleccionado == 'ROLE_MEDICO')
       {
           return $this->redirect($this->generateUrl('menu_medico'));
       }

       if ($rolSeleccionado == 'ROLE_SECRETARIA')
       {
           return $this->redirect($this->generateUrl('menu_secretaria'));
       }

       if ($rolSeleccionado == 'ROLE_ADMINISTRADOR')
       {
           return $this->redirect($this->generateUrl('menu_administrador'));
       }


    }
}
