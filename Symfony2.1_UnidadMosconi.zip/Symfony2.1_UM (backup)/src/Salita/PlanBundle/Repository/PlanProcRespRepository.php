<?php

namespace Salita\PlanBundle\Repository;

use Doctrine\ORM\EntityRepository;

class PlanProcRespRepository extends EntityRepository
{
    public function findAllById($id)
    {
        $idAux = "'%".$id."%'";
        $sql="SELECT p.id as id, p.periodicidad as periodicidad, m.nombre as nombre FROM SalitaPlanBundle:PlanProcResp p JOIN p.metodoAnticonceptivo m WHERE p.paciente= ".$id." AND p.finalizado = 0";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function findAllByIdDes($id)
    {
        $idAux = "'%".$id."%'";
        $sql="SELECT p.id as id, p.periodicidad as periodicidad, m.nombre as nombre FROM SalitaPlanBundle:PlanProcResp p JOIN p.metodoAnticonceptivo m WHERE p.paciente= ".$id." AND p.finalizado = 1";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function habilitar($id)
    {
        $idAux = "'%".$id."%'";
        $sql="UPDATE SalitaPlanBundle:PlanProcResp p SET p.finalizado=0 WHERE p.id = ".$id."";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function deshabilitar($id)
    {
        $idAux = "'%".$id."%'";
        $sql="UPDATE SalitaPlanBundle:PlanProcResp p SET p.finalizado=1 WHERE p.id = ".$id."";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }
}
