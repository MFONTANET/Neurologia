<?php

namespace Salita\PlanBundle\Controller;

use Salita\PlanBundle\Form\Type\PlanProcRespType;
use Salita\PlanBundle\Form\Type\ModPlanProcRespType;
use Salita\PlanBundle\Entity\PlanProcResp;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;

class PlanProcRespFormController extends Controller
{

    public function newAction(Request $request)
    {
        $plan= new PlanProcResp();
        $form = $this->createForm(new PlanProcRespType(),$plan);

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);

            if ($form->isValid())
            {
                //$_SESSION['idPaciente'] = 1; //dato de prueba!
                $repPlan = $this->getDoctrine()->getRepository('SalitaPacienteBundle:Paciente');
                $paciente = $repPlan->find($_SESSION['idPaciente']);
                $plan->setPaciente($paciente);
                $plan->setFinalizado('0');
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist($plan);
                $em->flush();
                return $this->render('SalitaPlanBundle:PlanProcRespForm:mensaje.html.twig', array('mensaje' => 'El plan del paciente se agrego  exitosamente','rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            }
            else 
            {
                return $this->render('SalitaPlanBundle:PlanProcRespForm:mensaje.html.twig', array('mensaje' => 'Se produjo un error al intentar agregar un plan para el paciente','rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            
            }
        }
        else
        {
            return $this->render('SalitaPlanBundle:PlanProcRespForm:new.html.twig', array('form' => $form->createView(),'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),
            ));
        }
    }

    public function modifAction(Request $request, $idPlan)
    {
        $em = $this->getDoctrine()->getEntityManager();
        $plan = $em->getRepository('SalitaPlanBundle:PlanProcResp')->find($idPlan);
        $form = $this->createForm(new ModPlanProcRespType(),$plan);

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);
            
            if ($form->isValid())
            {
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist($plan);
                $em->flush();
                return $this->render('SalitaPlanBundle:PlanProcRespForm:mensaje.html.twig', array('mensaje' => 'El plan del paciente se modifico exitosamente','rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            }
            else 
            {
                return $this->render('SalitaPlanBundle:PlanProcRespForm:mensaje.html.twig', array('mensaje' => 'Se produjo un error al intentar modificar un plan del paciente','rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            }
            
        }
        else
        {
            return $this->render('SalitaPlanBundle:PlanProcRespForm:modif.html.twig', array('form' => $form->createView(),'id' => $idPlan,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),
            ));
        }
    }

    function listAction(Request $request)
    {
        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        $planes = $em->getRepository('SalitaPlanBundle:PlanProcResp')->findAllById($_SESSION['idPaciente']);
        #$_SESSION['idPlan']= $planes->getId();
        return $this->render('SalitaPlanBundle:PlanProcRespForm:listado.html.twig', array('planes' => $planes,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),
            ));
    }

    function listDesAction(Request $request)
    {
        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        $planes = $em->getRepository('SalitaPlanBundle:PlanProcResp')->findAllByIdDes($_SESSION['idPaciente']);
        return $this->render('SalitaPlanBundle:PlanProcRespForm:listadoDes.html.twig', array('planes' => $planes,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),
            ));
    }

    function habAction(Request $request, $idPlan)
    {
        $em = $this->getDoctrine()->getEntityManager();
        $hab = $em->getRepository('SalitaPlanBundle:PlanProcResp')->habilitar($idPlan);
        return $this->redirect($this->generateUrl('listadoDes_planprocresp'));
    }

    function deshabAction(Request $request, $idPlan)
    {
        //$plan = $this->getDoctrine()->getRepository('SalitaPlanBundle:PlanProcResp')->findOneById($idPlan);
        $em = $this->getDoctrine()->getEntityManager();
        $des = $em->getRepository('SalitaPlanBundle:PlanProcResp')->deshabilitar($idPlan);
        return $this->redirect($this->generateUrl('listado_planprocresp'));
    }
}
