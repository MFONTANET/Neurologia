<?php

namespace Salita\PlanBundle\Controller;

use Salita\PlanBundle\Form\Type\EntregaPlanProcRespType;
use Salita\PlanBundle\Entity\EntregaPlanProcResp;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;

class EntregaPlanProcRespFormController extends Controller
{

    public function newAction(Request $request, $idPlan)
    {
        $entrega= new EntregaPlanProcResp();
        $form = $this->createForm(new EntregaPlanProcRespType(),$entrega);

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);
            
            if ($form->isValid())
            {
                $repPlan = $this->getDoctrine()->getRepository('SalitaPlanBundle:PlanProcResp');
                $plan = $repPlan->find($idPlan);
                $entrega->setFecha(date("d-m-Y"));
                $entrega->setPlan($plan);
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist($entrega);
                $em->flush();
                return $this->render('SalitaPlanBundle:EntregaPlanProcRespForm:mensaje.html.twig', array('mensaje' => 'La entrega del plan se registro correctamente','rol' => $rolSeleccionado->getCodigo()));
            }
            else 
            {
                return $this->render('SalitaPlanBundle:EntregaPlanProcRespForm:mensaje.html.twig', array('mensaje' => 'Se produjo un error al intentar registrar una entrega del plan','rol' => $rolSeleccionado->getCodigo()));
            }
        }
        else
        {
            return $this->render('SalitaPlanBundle:EntregaPlanProcRespForm:new.html.twig', array('form' => $form->createView(), 'id' => $idPlan,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre()));
        }
    }

    function listAction(Request $request, $idPlan)
    {

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        $entregasplanprocresp = $em->getRepository('SalitaPlanBundle:EntregaPlanProcResp')->encontrarTodosOrdenadosPorFecha($idPlan);
        return $this->render('SalitaPlanBundle:EntregaPlanProcRespForm:listado.html.twig', array('entregasplanprocresp' => $entregasplanprocresp,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
    }
}
