<?php

namespace Salita\PlanBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SalitaPlanBundle extends Bundle
{
}
