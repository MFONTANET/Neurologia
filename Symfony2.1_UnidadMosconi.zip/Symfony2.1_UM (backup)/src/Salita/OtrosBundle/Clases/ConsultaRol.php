<?php

namespace Salita\OtrosBundle\Clases;

class ConsultaRol
{
    public function rolSeleccionado($em)
    {
        //$_SESSION['idRolSeleccionado'] = 1; //dato de prueba, en el controlador de "elegir rol para entrar en el sistema" setear esta variable
        $repRol = $em->getRepository('SalitaUsuarioBundle:Rol');
        return $repRol->find($_SESSION['idRolSeleccionado']);
    }
}
