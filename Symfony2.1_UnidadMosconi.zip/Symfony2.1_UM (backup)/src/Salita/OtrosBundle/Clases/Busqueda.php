<?php

namespace Salita\OtrosBundle\Clases;

class Busqueda
{
    protected $palabra;

    public function getPalabra()
    {
        return $this->palabra;
    }
    public function setPalabra($palabra)
    {
        $this->palabra = $palabra;
    }
}
