<?php

namespace Salita\OtrosBundle\Clases;

class ConsultaEspecialidad
{
    public function especialidad($em)
    {
        //$_SESSION['idEspecialidad'] = 3; //dato de prueba, en el controlador de "elegir rol para entrar en el sistema" setear esta variable
        $repEspecialidad = $em->getRepository('SalitaUsuarioBundle:Especialidad');
        return $repEspecialidad->find($_SESSION['idEspecialidad']);
    }
}
