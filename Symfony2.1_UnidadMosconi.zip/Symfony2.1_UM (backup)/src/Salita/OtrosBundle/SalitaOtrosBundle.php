<?php

namespace Salita\OtrosBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SalitaOtrosBundle extends Bundle
{
}
