<?php

namespace Salita\OtrosBundle\Controller;

use Salita\OtrosBundle\Form\Type\BusquedaType;
use Salita\OtrosBundle\Clases\Busqueda;

use Salita\OtrosBundle\Form\Type\BusquedaDiagnosticoType;
use Salita\OtrosBundle\Clases\BusquedaDiagnostico;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;

class BusquedaController extends Controller
{

    public function buscarAction(Request $request)
    {
        $busqueda= new Busqueda();
        $form = $this->createForm(new BusquedaType(),$busqueda);

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);
            
            if ($form->isValid())
            {
                 $em = $this->getDoctrine()->getEntityManager();
                 $rep = $em->getRepository('SalitaOtrosBundle:Vacuna');
                 $vacunas = $rep->buscarVacuna($busqueda->getPalabra());

                 return $this->render('SalitaOtrosBundle:Busqueda:resultado.html.twig', array('vacunas' => $vacunas,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),
            ));
            }
        }
        else
        {
            return $this->render('SalitaOtrosBundle:Busqueda:ingresoDatos.html.twig', array('form' => $form->createView(),'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),
            ));
        }
    }

    public function buscarDiagnosticoAction(Request $request)
    {
        $busqueda= new BusquedaDiagnostico();
        $form = $this->createForm(new BusquedaDiagnosticoType(),$busqueda);

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);
            
            if ($form->isValid())
            {
                 $em = $this->getDoctrine()->getEntityManager();
                 $rep = $em->getRepository('SalitaOtrosBundle:Diagnostico');
                 $diagnosticos = $rep->buscarDiagnostico($busqueda->getPalabra());

                 return $this->render('SalitaOtrosBundle:BusquedaDiagnostico:resultado.html.twig', array('diagnosticos' => $diagnosticos,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            }
        }
        else
        {
            return $this->render('SalitaOtrosBundle:BusquedaDiagnostico:ingresoDatos.html.twig', array('form' => $form->createView(),'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
        }
    }
}
