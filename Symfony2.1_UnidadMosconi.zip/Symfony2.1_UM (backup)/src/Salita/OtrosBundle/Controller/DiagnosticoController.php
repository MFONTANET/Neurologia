<?php

namespace Salita\OtrosBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DiagnosticoController extends Controller
{

    public function seleccionarAction(Request $request, $idDiagnostico)
    {
       $_SESSION['idDiagnosticoSeleccionado'] = $idDiagnostico; 
       return $this->redirect($this->generateUrl('alta_consulta'));
    }
}
