<?php

namespace Salita\OtrosBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class VacunaController extends Controller
{

    public function seleccionarAction(Request $request, $idVacuna)
    {
       $_SESSION['idVacunaSeleccionada'] = $idVacuna; 
       return $this->redirect($this->generateUrl('alta_aplicacion_vacuna'));
    }
}
