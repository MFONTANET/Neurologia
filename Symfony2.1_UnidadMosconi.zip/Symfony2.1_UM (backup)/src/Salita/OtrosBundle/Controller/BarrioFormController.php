<?php

namespace Salita\OtrosBundle\Controller;

use Salita\OtrosBundle\Form\Type\BarrioType;
use Salita\OtrosBundle\Entity\Barrio;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;

class BarrioFormController extends Controller
{

    public function newAction(Request $request)
    {
        $barrio= new Barrio();
        $form = $this->createForm(new BarrioType(),$barrio);

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);
            
            if ($form->isValid())
            {
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist($barrio);
                $em->flush();
                return $this->render('SalitaOtrosBundle:BarrioForm:mensaje.html.twig', array('mensaje' => 'El barrio se cargo exitosamente en el sistema','rol' => $rolSeleccionado->getCodigo(),));
            }
            else 
            {
                return $this->render('SalitaOtrosBundle:BarrioForm:mensaje.html.twig', array('mensaje' => 'Se produjo un error al intentar cargar el barrio al sistema','rol' => $rolSeleccionado->getCodigo(),
            ));
            }
        }
        else
        {
            return $this->render('SalitaOtrosBundle:BarrioForm:new.html.twig', array('form' => $form->createView(),'rol' => $rolSeleccionado->getCodigo(),
            ));
        }
    }
}
