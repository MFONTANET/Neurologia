<?php

namespace Salita\PacienteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SalitaPacienteBundle extends Bundle
{
}
