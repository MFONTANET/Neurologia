<?php
namespace Salita\PacienteBundle\Controller;

use Salita\PacienteBundle\Form\Type\AntecedentePersonalClinicoType;
use Salita\PacienteBundle\Entity\AntecedentePersonalClinico;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;

class AntecedentePersonalClinicoFormController extends Controller
{
   
    public function modifAction(Request $request)
    {
        $repAntecedente = $this->getDoctrine()->getRepository('SalitaPacienteBundle:AntecedentePersonalClinico');
        $antecedentes = $repAntecedente->buscarAntecedenteDePaciente($_SESSION['idPaciente']);
        $antecedentePersonalClinico = $antecedentes[0];

        $em = $this->getDoctrine()->getEntityManager();
        $consultaRol = new ConsultaRol();
        $rolSeleccionado = $consultaRol->rolSeleccionado($em);

        $form = $this->createForm(new AntecedentePersonalClinicoType(),$antecedentePersonalClinico);

        if ($request->getMethod() == 'POST')
        {
            $form->bindRequest($request);
            
            if ($form->isValid())
            {
                $em = $this->getDoctrine()->getEntityManager();
                $em->persist($antecedentePersonalClinico);
                $em->flush();
                return $this->render('SalitaPacienteBundle:AntecedentePersonalClinicoForm:mensaje.html.twig', array('mensaje' => 'Los antecedentes del paciente se modificaron exitosamente','rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            }
            else 
            {
                return $this->render('SalitaPacienteBundle:AntecedentePersonalClinicoForm:mensaje.html.twig', array('mensaje' => 'Se produjo un error al modificar los antecedentes del paciente','rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
            }  
        }
        else
        {
            return $this->render('SalitaPacienteBundle:AntecedentePersonalClinicoForm:modif.html.twig', array('form' => $form->createView(), 'rol' => $rolSeleccionado->getCodigo(), 'nombreRol' => $rolSeleccionado->getNombre(),
            ));
        }
    }
}
