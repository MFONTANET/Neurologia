<?php

namespace Salita\PacienteBundle\Controller;

use Salita\PacienteBundle\Form\Type\ConsultaType;
use Salita\PacienteBundle\Entity\Consulta;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;

class ConsultaFormController extends Controller
{

    public function newAction(Request $request)
    {
       if (! isset($_SESSION['idPaciente']))
       {
           return $this->redirect($this->generateUrl('busqueda_paciente'));
       }
       else
       {
           if (! isset($_SESSION['idDiagnosticoSeleccionado']))
           {
                return $this->redirect($this->generateUrl('busqueda_diagnostico'));
           }
           else
           {
                $consulta = new Consulta();
                $form = $this->createForm(new ConsultaType(),$consulta);

                $em = $this->getDoctrine()->getEntityManager();
                $consultaRol = new ConsultaRol();
                $rolSeleccionado = $consultaRol->rolSeleccionado($em);

                if ($request->getMethod() == 'POST')
                {
                    $form->bindRequest($request);
 
                    if ($form->isValid())
                    {
                        //$_SESSION['idUsuario'] = 1; //dato de prueba

                        $em = $this->getDoctrine()->getEntityManager();
                        $repPaciente = $em->getRepository('SalitaPacienteBundle:Paciente');
                        $repUsuario = $em->getRepository('SalitaUsuarioBundle:Usuario');
                        $repDiagnostico = $em->getRepository('SalitaOtrosBundle:Diagnostico');

                        $paciente = $repPaciente->findOneById($_SESSION['idPaciente']);
                        $usuario = $repUsuario->findOneById($_SESSION['idUsuario']);
                        $diagnostico = $repDiagnostico->findOneById($_SESSION['idDiagnosticoSeleccionado']);

                        $consulta->setPaciente($paciente);
                        $consulta->setUsuario($usuario);
                        $consulta->setDiagnostico($diagnostico);
                        $consulta->setFecha(date("d-m-Y"));
                        $consulta->setHora(date("H:i:s"));

                        $em->persist($consulta);
                        $em->flush();
                        unset($_SESSION['idDiagnosticoSeleccionado']);

                        return $this->redirect($this->generateUrl('menu_paciente'));
                    }
                    else
                    {
                        return $this->render('SalitaPacienteBundle:ConsultaForm:mensaje.html.twig', array('mensaje' => 'Se produjo un error al cargar la consulta en el sistema',));
                    }
                }
                else
                {
                     return $this->render('SalitaPacienteBundle:ConsultaForm:new.html.twig', array('form' => $form->createView(),'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
                } 
           }
       }
    }
}
