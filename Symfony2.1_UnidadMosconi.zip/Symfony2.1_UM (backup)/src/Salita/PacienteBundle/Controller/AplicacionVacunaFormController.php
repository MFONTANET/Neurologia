<?php

namespace Salita\PacienteBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Entity\AplicacionVacuna;

use Salita\OtrosBundle\Clases\ConsultaRol;

class AplicacionVacunaFormController extends Controller
{

    public function newAction(Request $request)
    {
       if (! isset($_SESSION['idPaciente']))
       {
           return $this->redirect($this->generateUrl('busqueda_paciente'));
       }
       else
       {
           if (! isset($_SESSION['idVacunaSeleccionada']))
           {
                return $this->redirect($this->generateUrl('busqueda_vacuna'));
           }
           else
           {
                
                $em = $this->getDoctrine()->getEntityManager();
                $repPaciente = $em->getRepository('SalitaPacienteBundle:Paciente');
                $repVacuna = $em->getRepository('SalitaOtrosBundle:Vacuna');

                $paciente = $repPaciente->findOneById($_SESSION['idPaciente']);
                $vacuna = $repVacuna->findOneById($_SESSION['idVacunaSeleccionada']);

                $aplicacion = new AplicacionVacuna();
                $aplicacion->setFecha(date("d-m-Y"));
                $aplicacion->setPaciente($paciente);
                $aplicacion->setVacuna($vacuna); 
                
                $em->persist($aplicacion);
                $em->persist($paciente);
                $em->flush();
                unset($_SESSION['idVacunaSeleccionada']);
           }
       }
       return $this->redirect($this->generateUrl('menu_paciente'));
    }

    public function listAction(Request $request)
    {
         if (! isset($_SESSION['idPaciente']))
         {
             return $this->redirect($this->generateUrl('busqueda_paciente'));
         }
         else
         {

             $em = $this->getDoctrine()->getEntityManager();
             $consultaRol = new ConsultaRol();
             $rolSeleccionado = $consultaRol->rolSeleccionado($em);

             $repPaciente = $em->getRepository('SalitaPacienteBundle:Paciente');
             $aplicaciones = $repPaciente->aplicacionesVacuna($_SESSION['idPaciente']);
             return $this->render('SalitaPacienteBundle:AplicacionVacuna:list.html.twig', array('aplicaciones' => $aplicaciones,'rol' => $rolSeleccionado->getCodigo(),'nombreRol' => $rolSeleccionado->getNombre(),));
         }
    }
}
