<?php

namespace Salita\PacienteBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Salita\OtrosBundle\Clases\ConsultaRol;
use Salita\OtrosBundle\Clases\ConsultaEspecialidad;

class MenuController extends Controller
{

    public function principalAction(Request $request)
    {
       if(! isset($_SESSION['idPaciente']))
       {
           return $this->redirect($this->generateUrl('busqueda_paciente'));
       }
       else
       {

           $em = $this->getDoctrine()->getEntityManager();
           $consultaRol = new ConsultaRol();
           $rolSeleccionado = $consultaRol->rolSeleccionado($em);

           if ($rolSeleccionado->getCodigo() == 'ROLE_MEDICO')
           {
               $consultaEspecialidad = new ConsultaEspecialidad();
               $especialidad = $consultaEspecialidad->especialidad($em);
               $codigoEspecialidad = $especialidad->getCodigo();
           }
           else 
           {
               $codigoEspecialidad = 'NO TIENE';
           }

           $repPac = $this->getDoctrine()->getRepository('SalitaPacienteBundle:Paciente');
           $paciente = $repPac->findOneById($_SESSION['idPaciente']);

           return $this->render('SalitaPacienteBundle:Menu:principal.html.twig', array('paciente' => $paciente, 'rol' =>$rolSeleccionado->getCodigo(), 'nombreRol' =>$rolSeleccionado->getNombre(),'especialidad' => $codigoEspecialidad,));
       }
    }
}
