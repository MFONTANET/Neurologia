<?php

namespace Salita\PacienteBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class SeleccionController extends Controller
{

    public function seleccionarAction(Request $request, $idPaciente)
    {
       $_SESSION['idPaciente'] = $idPaciente;
       return $this->redirect($this->generateUrl('menu_paciente'));
    }
}
