<?php

namespace Salita\PacienteBundle\Repository;

use Doctrine\ORM\EntityRepository;

class PacienteRepository extends EntityRepository
{
    public function buscarPorNombre($nombre)
    {
        $nombreAux = "'%".$nombre."%'";
        $sql = "SELECT p FROM SalitaPacienteBundle:Paciente p WHERE p.nombre like ".$nombreAux." ORDER BY p.nombre ASC";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function buscarPorApellido($apellido)
    {
        $apellidoAux = "'%".$apellido."%'";
        $sql = "SELECT p FROM SalitaPacienteBundle:Paciente p WHERE p.apellido like ".$apellidoAux." ORDER BY p.apellido ASC";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function buscarPorDNI($dni)
    {
        $dniAux = "'%".$dni."%'";
        $sql = "SELECT p FROM SalitaPacienteBundle:Paciente p WHERE p.nroDoc LIKE ".$dniAux." ORDER BY p.apellido ASC";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function aplicacionesVacuna($idPaciente)
    {
        $sql = "SELECT a.fecha as fecha, v.nombre as nombre FROM SalitaOtrosBundle:AplicacionVacuna a JOIN a.vacuna v WHERE a.paciente = ".$idPaciente. " ORDER BY a.fecha ASC";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function buscarDatosFiliatorios($idPaciente)
    {
        $sql = "SELECT p FROM SalitaPacienteBundle:Paciente p WHERE p.id = ".$idPaciente."";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }
}
