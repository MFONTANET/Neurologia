<?php

namespace Salita\TurnoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SalitaTurnoBundle extends Bundle
{
}
