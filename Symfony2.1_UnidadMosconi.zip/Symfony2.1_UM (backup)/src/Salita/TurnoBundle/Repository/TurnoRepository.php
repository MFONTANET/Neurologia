<?php

namespace Salita\TurnoBundle\Repository;

use Doctrine\ORM\EntityRepository;

class TurnoRepository extends EntityRepository
{
    public function turnosDelDia()
    {
        $fechaHoy = "'".Date("d-m-Y")."'";
        $sql = "SELECT p.nombre as nombre,p.apellido as apellido,t.motivo as motivo, t.fecha as fecha,t.hora as hora, t.medicoPreferido as medico, t.id as id, e.nombre as especialidad FROM SalitaTurnoBundle:Turno t JOIN t.paciente p JOIN t.especialidad e WHERE t.fecha=".$fechaHoy." AND t.atendido = false";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }

    public function turnosDelDiaDeEspecialidad()
    {
        $idEspecialidad = $_SESSION['idEspecialidad'];
        $fechaHoy = "'".Date("d-m-Y")."'";
        $sql = "SELECT p.nombre as nombre,p.apellido as apellido,t.motivo as motivo,t.fecha as fecha,t.hora as hora, t.medicoPreferido as medico, t.id as id FROM SalitaTurnoBundle:Turno t JOIN t.paciente p JOIN t.especialidad e WHERE t.fecha=".$fechaHoy. " AND e.id=".$idEspecialidad." AND t.atendido = false";
        return $this->getEntityManager()
            ->createQuery($sql)
            ->getResult();
    }
}
